# 3110Project

Mahjong OCaml!

Project Members:
1. Alexander Peek (ap2298)
2. Jonathan Yen (jfy7)
3. Jonathan Lee (jdl282)
